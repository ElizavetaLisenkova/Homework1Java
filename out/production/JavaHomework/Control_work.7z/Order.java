package Control_work;

import java.util.ArrayList;
import java.util.Arrays;

public class Order {

    private int table;
    private Double orderPrice;
    private ArrayList<Dish> orderingDishes;

    public Order(int table, ) {
        ar.addAll(Arrays.asList(d1, d2));
    }
}
